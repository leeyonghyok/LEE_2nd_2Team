# LightGBM_pipeline_02_training.py
# -*- coding: utf-8 -*-
"""
[Pipeline 2] LightGBM 모델 학습, 평가
-------------------------------------------------------------------------
4. LightGBM 모델 생성 및 학습 (early_stopping 적용 포함)
5. 테스트 데이터를 활용한 모델 예측 및 평가 (정확도, ROC-AUC, 분류 리포트)
6. 피처 중요도(Feature Importance) 그래프 저장
"""

import pandas as pd
import lightgbm as lgb
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, accuracy_score, roc_auc_score

def run_model_training_and_evaluation(X_train, X_test, y_train, y_test, best_params=None):
    # 전처리가 실행되지 않았을 경우 오류 메세지 노출
    if X_train is None:
        print("[오류] 입력 데이터가 올바르지 않습니다.")
        return

    # 4. LightGBM 모델 생성 및 학습
    # 기본 설정 지정 > 튜닝 후 최적 파라미터(best_params)가 들어오면 해당 값으로 변경 실행 
    lr = best_params['learning_rate'] if best_params else 0.05
    num_leaves = best_params['num_leaves'] if best_params else 31
    max_depth = best_params['max_depth'] if best_params else -1

    print(f"최종 모델 파라미터 -> lr: {lr}, num_leaves: {num_leaves}, max_depth: {max_depth}")

    model = lgb.LGBMClassifier(
        n_estimators=500,       # 반복횟수를 크게 지정 > 밑에서 early_stopping 설정.
        learning_rate=lr,     
        num_leaves=num_leaves,          
        max_depth=max_depth,           
        random_state=42,
        class_weight='balanced' 
    )

    model.fit(
        X_train, y_train,
        eval_set=[(X_test, y_test)],
        callbacks=[
            # n_estimators=500으로 크게 지정해두었기때문에, 최고 성능이 도달했을때 stopping_rounds만큼만 더 반복하고 
            # 더이상 성능에 변화가 없으면 반복을 멈추도록 early_stopping 설정.
            # 과적합을 방지하고 시간과 메모리 낭비를 줄일 수 있음.
            lgb.early_stopping(stopping_rounds=10, verbose=False), 
            lgb.log_evaluation(period=50)
        ]
    )
    print("모델 생성 및 학습 완료")

    # 5. 모델 평가
    y_pred = model.predict(X_test)
    y_pred_proba = model.predict_proba(X_test)[:, 1]

    print("\n------------------ [ LightGBM 모델 평가 결과 ] ------------------")
    print(f"1. 정확도 (Accuracy): {accuracy_score(y_test, y_pred):.4f}")
    print(f"2. ROC-AUC 점수     : {roc_auc_score(y_test, y_pred_proba):.4f}")
    print("\n3. 분류 리포트 (Classification Report):")
    print(classification_report(y_test, y_pred))
    print("-----------------------------------------------------------------")

    # 6. 피처 중요도 (Feature Importance) 그래프 생성한 후 그림파일로 저장하기
    importance_df = pd.DataFrame({
        'Feature': X_train.columns,
        'Importance': model.feature_importances_
    }).sort_values(by='Importance', ascending=False)

    sns.set_theme(style="whitegrid")
    # OS별 폰트 확인하기
    for font in ['Malgun Gothic', 'AppleGothic', 'NanumGothic', 'DejaVu Sans']:
        try:
            plt.rcParams['font.family'] = font
            break
        except:
            pass
    plt.rcParams['axes.unicode_minus'] = False

    plt.figure(figsize=(10, 6))
    sns.barplot(x='Importance', y='Feature', data=importance_df, palette='viridis')
    plt.title('LightGBM Feature Importance for Churn Prediction', fontsize=14)
    plt.xlabel('Importance')
    plt.tight_layout()
    
    output_image = 'lgb_feature_importance.png'
    plt.savefig(output_image, dpi=150)
    plt.close()
    print(f"피처 중요도 그래프 저장: '{output_image}'")
    print("-----------------------------------------------------------------")

if __name__ == '__main__':
    # pipeline_02_training.py 파일을 독립 실행 시 자동으로 pipeline_01_preprocessing.py 파일을 실행
    try:
        import LightGBM_pipeline_01_preprocessing as p1
        X_train, X_test, y_train, y_test = p1.run_preprocessing()
        if X_train is not None:
            run_model_training_and_evaluation(X_train, X_test, y_train, y_test)
    # pipeline_01_preprocessing.py 파일 자동실행이 실패할 때 오류 메세지 노출
    except ImportError:
        print("[오류] 'LightGBM_pipeline_01_preprocessing.py' 파일이 동일 폴더에 있어야 자동으로 실행합니다.")